require('dotenv').config();
const { initializeDatabase } = require('./config/database');
const app = require('./app');

const port = Number(process.env.PORT) || 3000;
const requiredEnvironment = ['JWT_SECRET'];

async function start() {
  const missing = requiredEnvironment.filter((key) => !process.env[key]);
  if (missing.length) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }

  await initializeDatabase();
  app.listen(port, () => {
    console.log(`API server listening on port ${port}`);
    console.log(`SQLite database ready at ${process.env.DATABASE_PATH || './data/course_api.sqlite'}`);
  });
}

start().catch((error) => {
  console.error('Failed to start the API server:', error.message);
  process.exitCode = 1;
});
