const Category = require('./category.model');
const ApiError = require('../../utils/api-error');
const asyncHandler = require('../../utils/async-handler');

const listCategories = asyncHandler(async (req, res) => {
  const categories = Category.listByUser(req.user.id);
  return res.status(200).json({ success: true, data: categories });
});

const getCategory = asyncHandler(async (req, res) => {
  const category = Category.findByIdAndUser(req.params.id, req.user.id);
  if (!category) {
    throw new ApiError(404, 'Category not found.');
  }
  return res.status(200).json({ success: true, data: category });
});

const createCategory = asyncHandler(async (req, res) => {
  const category = Category.create({
    name: req.body.name,
    description: req.body.description,
    userId: req.user.id
  });
  return res.status(201).json({
    success: true,
    message: 'Category created successfully.',
    data: category
  });
});

const updateCategory = asyncHandler(async (req, res) => {
  const updates = {};
  for (const field of ['name', 'description']) {
    if (Object.prototype.hasOwnProperty.call(req.body, field)) {
      updates[field] = req.body[field];
    }
  }

  const category = Category.update(req.params.id, req.user.id, updates);
  if (!category) {
    throw new ApiError(404, 'Category not found.');
  }
  return res.status(200).json({
    success: true,
    message: 'Category updated successfully.',
    data: category
  });
});

const deleteCategory = asyncHandler(async (req, res) => {
  const category = Category.findByIdAndUser(req.params.id, req.user.id);
  if (!category) {
    throw new ApiError(404, 'Category not found.');
  }

  const hasCourses = Category.hasCourses(category.id, req.user.id);
  if (hasCourses) {
    throw new ApiError(409, 'Cannot delete a category that contains courses.');
  }

  Category.remove(category.id, req.user.id);
  return res.status(200).json({ success: true, message: 'Category deleted successfully.' });
});

module.exports = { listCategories, getCategory, createCategory, updateCategory, deleteCategory };
