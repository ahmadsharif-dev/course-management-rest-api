const express = require('express');
const requireAuth = require('../../middleware/auth.middleware');
const { validate, idRules, createRules, updateRules } = require('./category.validation');
const controller = require('./category.controller');

const router = express.Router();

router.use(requireAuth);
router.route('/')
  .get(controller.listCategories)
  .post(createRules, validate, controller.createCategory);
router.route('/:id')
  .get(idRules, validate, controller.getCategory)
  .patch(idRules, updateRules, validate, controller.updateCategory)
  .delete(idRules, validate, controller.deleteCategory);

module.exports = router;
