const { body, param } = require('express-validator');
const validate = require('../../middleware/validate.middleware');

const createRules = [
  body('name')
    .trim()
    .notEmpty().withMessage('Name is required.')
    .bail()
    .isLength({ min: 2, max: 80 }).withMessage('Name must be between 2 and 80 characters.'),
  body('description')
    .optional()
    .isString().withMessage('Description must be a string.')
    .bail()
    .trim()
    .isLength({ max: 500 }).withMessage('Description cannot exceed 500 characters.')
];

const updateRules = [
  body().custom((value) => {
    if (!value || (!Object.prototype.hasOwnProperty.call(value, 'name')
      && !Object.prototype.hasOwnProperty.call(value, 'description'))) {
      throw new Error('Provide at least one field to update: name or description.');
    }
    return true;
  }),
  body('name')
    .optional()
    .trim()
    .notEmpty().withMessage('Name cannot be empty.')
    .bail()
    .isLength({ min: 2, max: 80 }).withMessage('Name must be between 2 and 80 characters.'),
  body('description')
    .optional()
    .isString().withMessage('Description must be a string.')
    .bail()
    .trim()
    .isLength({ max: 500 }).withMessage('Description cannot exceed 500 characters.')
];

const idRules = [
  param('id').isInt({ min: 1 }).withMessage('Invalid resource ID.').toInt()
];

module.exports = { createRules, updateRules, idRules, validate };
