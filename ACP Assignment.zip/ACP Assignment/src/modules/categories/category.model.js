const { all, get, run } = require('../../config/database');

const fields = `
  id,
  name,
  description,
  user_id AS userId,
  created_at AS createdAt,
  updated_at AS updatedAt
`;

function listByUser(userId) {
  return all(`
    SELECT ${fields}
    FROM categories
    WHERE user_id = ?
    ORDER BY created_at DESC, id DESC
  `, [userId]);
}

function findByIdAndUser(id, userId) {
  return get(`
    SELECT ${fields}
    FROM categories
    WHERE id = ? AND user_id = ?
  `, [id, userId]);
}

function create({ name, description = '', userId }) {
  const result = run(`
    INSERT INTO categories (name, description, user_id)
    VALUES (?, ?, ?)
  `, [name, description, userId]);
  return findByIdAndUser(result.lastInsertRowid, userId);
}

function update(id, userId, updates) {
  const fields = Object.keys(updates);
  const assignments = fields.map((field) => `${field} = ?`);
  assignments.push("updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')");
  const result = run(`
    UPDATE categories SET ${assignments.join(', ')}
    WHERE id = ? AND user_id = ?
  `, [...fields.map((field) => updates[field]), id, userId]);
  return result.changes ? findByIdAndUser(id, userId) : null;
}

function hasCourses(id, userId) {
  return Boolean(get(`
    SELECT 1 FROM courses WHERE category_id = ? AND user_id = ? LIMIT 1
  `, [id, userId]));
}

function remove(id, userId) {
  return run('DELETE FROM categories WHERE id = ? AND user_id = ?', [id, userId]).changes > 0;
}

module.exports = { listByUser, findByIdAndUser, create, update, hasCourses, remove };
