const express = require('express');
const requireAuth = require('../../middleware/auth.middleware');
const { validate, idRules, createRules, updateRules } = require('./course.validation');
const controller = require('./course.controller');

const router = express.Router();

router.use(requireAuth);
router.route('/')
  .get(controller.listCourses)
  .post(createRules, validate, controller.createCourse);
router.route('/:id')
  .get(idRules, validate, controller.getCourse)
  .patch(idRules, updateRules, validate, controller.updateCourse)
  .delete(idRules, validate, controller.deleteCourse);

module.exports = router;
