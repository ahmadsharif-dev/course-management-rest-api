const { all, get, run } = require('../../config/database');

const fields = `
  courses.id,
  courses.title,
  courses.description,
  courses.price,
  courses.level,
  courses.category_id AS categoryId,
  courses.user_id AS userId,
  categories.name AS categoryName,
  courses.created_at AS createdAt,
  courses.updated_at AS updatedAt
`;

function listByUser(userId) {
  return all(`
    SELECT ${fields}
    FROM courses
    JOIN categories ON categories.id = courses.category_id
    WHERE courses.user_id = ?
    ORDER BY courses.created_at DESC, courses.id DESC
  `, [userId]);
}

function findByIdAndUser(id, userId) {
  return get(`
    SELECT ${fields}
    FROM courses
    JOIN categories ON categories.id = courses.category_id
    WHERE courses.id = ? AND courses.user_id = ?
  `, [id, userId]);
}

function create({ title, description = '', price, level = 'beginner', categoryId, userId }) {
  const result = run(`
    INSERT INTO courses (title, description, price, level, category_id, user_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `, [title, description, price, level, categoryId, userId]);
  return findByIdAndUser(result.lastInsertRowid, userId);
}

function update(id, userId, updates) {
  const columns = {
    title: 'title',
    description: 'description',
    price: 'price',
    level: 'level',
    categoryId: 'category_id'
  };
  const fieldsToUpdate = Object.keys(updates);
  const assignments = fieldsToUpdate.map((field) => `${columns[field]} = ?`);
  assignments.push("updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')");
  const result = run(`
    UPDATE courses SET ${assignments.join(', ')}
    WHERE id = ? AND user_id = ?
  `, [...fieldsToUpdate.map((field) => updates[field]), id, userId]);
  return result.changes ? findByIdAndUser(id, userId) : null;
}

function remove(id, userId) {
  return run('DELETE FROM courses WHERE id = ? AND user_id = ?', [id, userId]).changes > 0;
}

module.exports = { listByUser, findByIdAndUser, create, update, remove };
