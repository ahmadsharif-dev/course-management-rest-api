const Course = require('./course.model');
const Category = require('../categories/category.model');
const ApiError = require('../../utils/api-error');
const asyncHandler = require('../../utils/async-handler');

async function ensureOwnedCategory(categoryId, userId) {
  const category = Category.findByIdAndUser(categoryId, userId);
  if (!category) {
    throw new ApiError(400, 'The selected category does not exist or is not accessible.');
  }
}

const listCourses = asyncHandler(async (req, res) => {
  const courses = Course.listByUser(req.user.id);
  return res.status(200).json({ success: true, data: courses });
});

const getCourse = asyncHandler(async (req, res) => {
  const course = Course.findByIdAndUser(req.params.id, req.user.id);
  if (!course) {
    throw new ApiError(404, 'Course not found.');
  }
  return res.status(200).json({ success: true, data: course });
});

const createCourse = asyncHandler(async (req, res) => {
  await ensureOwnedCategory(req.body.categoryId, req.user.id);
  const course = Course.create({
    title: req.body.title,
    description: req.body.description,
    price: req.body.price,
    level: req.body.level,
    categoryId: req.body.categoryId,
    userId: req.user.id
  });
  return res.status(201).json({
    success: true,
    message: 'Course created successfully.',
    data: course
  });
});

const updateCourse = asyncHandler(async (req, res) => {
  const existingCourse = Course.findByIdAndUser(req.params.id, req.user.id);
  if (!existingCourse) {
    throw new ApiError(404, 'Course not found.');
  }

  if (req.body.categoryId) {
    await ensureOwnedCategory(req.body.categoryId, req.user.id);
  }

  const fields = ['title', 'description', 'price', 'level', 'categoryId'];
  const updates = {};
  for (const field of fields) {
    if (Object.prototype.hasOwnProperty.call(req.body, field)) {
      updates[field] = req.body[field];
    }
  }
  const course = Course.update(req.params.id, req.user.id, updates);

  return res.status(200).json({
    success: true,
    message: 'Course updated successfully.',
    data: course
  });
});

const deleteCourse = asyncHandler(async (req, res) => {
  const removed = Course.remove(req.params.id, req.user.id);
  if (!removed) {
    throw new ApiError(404, 'Course not found.');
  }
  return res.status(200).json({ success: true, message: 'Course deleted successfully.' });
});

module.exports = { listCourses, getCourse, createCourse, updateCourse, deleteCourse };
