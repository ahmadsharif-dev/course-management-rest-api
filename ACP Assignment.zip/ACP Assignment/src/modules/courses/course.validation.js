const { body, param } = require('express-validator');
const validate = require('../../middleware/validate.middleware');

const levels = ['beginner', 'intermediate', 'advanced'];

const createRules = [
  body('title')
    .trim()
    .notEmpty().withMessage('Title is required.')
    .bail()
    .isLength({ min: 2, max: 120 }).withMessage('Title must be between 2 and 120 characters.'),
  body('description')
    .optional()
    .isString().withMessage('Description must be a string.')
    .bail()
    .trim()
    .isLength({ max: 2000 }).withMessage('Description cannot exceed 2000 characters.'),
  body('price')
    .notEmpty().withMessage('Price is required.')
    .bail()
    .isFloat({ min: 0 }).withMessage('Price must be a number greater than or equal to 0.')
    .toFloat(),
  body('level')
    .optional()
    .isIn(levels).withMessage(`Level must be one of: ${levels.join(', ')}.`),
  body('categoryId')
    .notEmpty().withMessage('Category ID is required.')
    .bail()
    .isInt({ min: 1 }).withMessage('Category ID must be a valid ID.')
    .toInt()
];

const updateRules = [
  body().custom((value) => {
    const fields = ['title', 'description', 'price', 'level', 'categoryId'];
    if (!value || !fields.some((field) => Object.prototype.hasOwnProperty.call(value, field))) {
      throw new Error('Provide at least one field to update.');
    }
    return true;
  }),
  body('title')
    .optional()
    .trim()
    .notEmpty().withMessage('Title cannot be empty.')
    .bail()
    .isLength({ min: 2, max: 120 }).withMessage('Title must be between 2 and 120 characters.'),
  body('description')
    .optional()
    .isString().withMessage('Description must be a string.')
    .bail()
    .trim()
    .isLength({ max: 2000 }).withMessage('Description cannot exceed 2000 characters.'),
  body('price')
    .optional()
    .isFloat({ min: 0 }).withMessage('Price must be a number greater than or equal to 0.')
    .toFloat(),
  body('level')
    .optional()
    .isIn(levels).withMessage(`Level must be one of: ${levels.join(', ')}.`),
  body('categoryId')
    .optional()
    .isInt({ min: 1 }).withMessage('Category ID must be a valid ID.')
    .toInt()
];

const idRules = [param('id').isInt({ min: 1 }).withMessage('Invalid resource ID.').toInt()];

module.exports = { createRules, updateRules, idRules, validate };
