const express = require('express');
const validate = require('../../middleware/validate.middleware');
const { register, login } = require('./auth.controller');
const { registerRules, loginRules } = require('./auth.validation');

const router = express.Router();

router.post('/register', registerRules, validate, register);
router.post('/login', loginRules, validate, login);

module.exports = router;
