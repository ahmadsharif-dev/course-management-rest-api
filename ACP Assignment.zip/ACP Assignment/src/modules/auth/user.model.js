const bcrypt = require('bcryptjs');
const { get, run } = require('../../config/database');

async function create({ name, email, password }) {
  const passwordHash = await bcrypt.hash(password, 12);
  const result = run(`
    INSERT INTO users (name, email, password_hash)
    VALUES (?, ?, ?)
  `, [name, email, passwordHash]);
  return get('SELECT id, name, email FROM users WHERE id = ?', [result.lastInsertRowid]);
}

function findByEmail(email) {
  return get(`
    SELECT id, name, email, password_hash AS passwordHash
    FROM users
    WHERE email = ?
  `, [email]);
}

function comparePassword(password, passwordHash) {
  return bcrypt.compare(password, passwordHash);
}

module.exports = { create, findByEmail, comparePassword };
