const { body } = require('express-validator');

const registerRules = [
  body('name')
    .trim()
    .notEmpty().withMessage('Name is required.')
    .bail()
    .isLength({ min: 2, max: 80 }).withMessage('Name must be between 2 and 80 characters.'),
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required.')
    .bail()
    .isEmail().withMessage('Provide a valid email address.')
    .normalizeEmail(),
  body('password')
    .notEmpty().withMessage('Password is required.')
    .bail()
    .isLength({ min: 8, max: 72 }).withMessage('Password must be between 8 and 72 characters.')
];

const loginRules = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required.')
    .bail()
    .isEmail().withMessage('Provide a valid email address.')
    .normalizeEmail(),
  body('password')
    .notEmpty().withMessage('Password is required.')
];

module.exports = { registerRules, loginRules };
