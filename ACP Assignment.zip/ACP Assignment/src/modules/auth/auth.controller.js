const jwt = require('jsonwebtoken');
const User = require('./user.model');
const ApiError = require('../../utils/api-error');
const asyncHandler = require('../../utils/async-handler');

function createToken(userId) {
  return jwt.sign({}, process.env.JWT_SECRET, {
    subject: userId.toString(),
    expiresIn: process.env.JWT_EXPIRES_IN || '1d'
  });
}

const register = asyncHandler(async (req, res) => {
  const user = await User.create({
    name: req.body.name,
    email: req.body.email,
    password: req.body.password
  });
  const token = createToken(user.id);

  return res.status(201).json({
    success: true,
    message: 'Registration successful.',
    data: {
      user: { id: user.id, name: user.name, email: user.email },
      token
    }
  });
});

const login = asyncHandler(async (req, res) => {
  const user = User.findByEmail(req.body.email);
  if (!user || !(await User.comparePassword(req.body.password, user.passwordHash))) {
    throw new ApiError(401, 'Invalid email or password.');
  }

  return res.status(200).json({
    success: true,
    message: 'Login successful.',
    data: {
      user: { id: user.id, name: user.name, email: user.email },
      token: createToken(user.id)
    }
  });
});

module.exports = { register, login };
