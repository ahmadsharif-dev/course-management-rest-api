const { validationResult } = require('express-validator');
const ApiError = require('../utils/api-error');

function validate(req, res, next) {
  const result = validationResult(req);
  if (!result.isEmpty()) {
    return next(new ApiError(400, 'Validation failed.', result.array().map((error) => ({
      field: error.path,
      message: error.msg
    }))));
  }
  return next();
}

module.exports = validate;
