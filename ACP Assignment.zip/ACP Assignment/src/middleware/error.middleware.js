const ApiError = require('../utils/api-error');

function notFound(req, res, next) {
  next(new ApiError(404, `Route not found: ${req.method} ${req.originalUrl}`));
}

function errorHandler(error, req, res, next) {
  if (res.headersSent) {
    return next(error);
  }

  let statusCode = error.statusCode || error.status || 500;
  let message = error.message || 'Internal server error.';
  let details = error.details;

  if (error.type === 'entity.parse.failed') {
    statusCode = 400;
    message = 'Request body contains invalid JSON.';
  } else if (error.code === 'SQLITE_CONSTRAINT_UNIQUE'
    || error.message.includes('UNIQUE constraint failed')) {
    statusCode = 409;
    message = 'A record with this value already exists.';
  } else if (error.code === 'SQLITE_CONSTRAINT_FOREIGNKEY'
    || error.message.includes('FOREIGN KEY constraint failed')) {
    statusCode = 400;
    message = 'The selected related record does not exist.';
  } else if (error.name === 'ValidationError') {
    statusCode = 400;
    message = 'Validation failed.';
    details = Object.values(error.errors).map((item) => ({
      field: item.path,
      message: item.message
    }));
  } else if (error.code === 11000) {
    statusCode = 409;
    message = 'A record with this value already exists.';
    details = Object.keys(error.keyPattern || {}).map((field) => ({
      field,
      message: `${field} is already in use.`
    }));
  }

  if (statusCode >= 500) {
    console.error(error);
    message = 'Internal server error.';
  }

  const body = { success: false, message };
  if (details) {
    body.errors = details;
  }
  if (process.env.NODE_ENV === 'development' && statusCode >= 500) {
    body.error = error.message;
  }

  return res.status(statusCode).json(body);
}

module.exports = { notFound, errorHandler };
