const jwt = require('jsonwebtoken');
const ApiError = require('../utils/api-error');

function requireAuth(req, res, next) {
  const authorization = req.get('authorization');
  if (!authorization || !authorization.startsWith('Bearer ')) {
    return next(new ApiError(401, 'Authentication required. Provide a Bearer token.'));
  }

  const token = authorization.slice(7).trim();
  if (!token) {
    return next(new ApiError(401, 'Authentication required. Provide a Bearer token.'));
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = { id: payload.sub };
    return next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError || error instanceof jwt.TokenExpiredError) {
      return next(new ApiError(401, 'Invalid or expired token.'));
    }
    return next(error);
  }
}

module.exports = requireAuth;
