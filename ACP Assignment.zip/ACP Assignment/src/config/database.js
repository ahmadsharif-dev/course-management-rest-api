const path = require('node:path');
const fs = require('node:fs');
const initializeSqlJs = require('sql.js');

const databasePath = process.env.DATABASE_PATH || path.join(__dirname, '../../data/course_api.sqlite');
if (databasePath !== ':memory:') {
  fs.mkdirSync(path.dirname(path.resolve(databasePath)), { recursive: true });
}

let db;

function getDatabase() {
  if (!db) {
    throw new Error('SQLite database has not been initialized.');
  }
  return db;
}

function all(sql, params = []) {
  const statement = getDatabase().prepare(sql);
  statement.bind(params);
  const rows = [];
  while (statement.step()) {
    rows.push(statement.getAsObject());
  }
  statement.free();
  return rows;
}

function get(sql, params = []) {
  return all(sql, params)[0];
}

function persist() {
  if (databasePath !== ':memory:') {
    fs.writeFileSync(databasePath, Buffer.from(getDatabase().export()));
  }
}

function run(sql, params = []) {
  const database = getDatabase();
  database.run(sql, params);
  const changes = database.getRowsModified();
  const lastInsertRowid = get('SELECT last_insert_rowid() AS id').id;
  persist();
  return { changes, lastInsertRowid };
}

async function initializeDatabase() {
  if (db) {
    return;
  }
  const SQL = await initializeSqlJs({
    locateFile: (file) => require.resolve(`sql.js/dist/${file}`)
  });
  if (databasePath !== ':memory:' && fs.existsSync(databasePath)) {
    db = new SQL.Database(new Uint8Array(fs.readFileSync(databasePath)));
  } else {
    db = new SQL.Database();
  }
  db.run('PRAGMA foreign_keys = ON');
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL CHECK (length(name) BETWEEN 2 AND 80),
      email TEXT NOT NULL COLLATE NOCASE UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL CHECK (length(name) BETWEEN 2 AND 80),
      description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 500),
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      UNIQUE (user_id, name)
    );

    CREATE TABLE IF NOT EXISTS courses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL CHECK (length(title) BETWEEN 2 AND 120),
      description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 2000),
      price REAL NOT NULL CHECK (price >= 0),
      level TEXT NOT NULL DEFAULT 'beginner'
        CHECK (level IN ('beginner', 'intermediate', 'advanced')),
      category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE INDEX IF NOT EXISTS categories_user_id_idx ON categories(user_id);
    CREATE INDEX IF NOT EXISTS courses_user_id_idx ON courses(user_id);
    CREATE INDEX IF NOT EXISTS courses_category_id_idx ON courses(category_id);
  `);
  persist();
}

module.exports = { all, get, run, initializeDatabase };
