const test = require('node:test');
const assert = require('node:assert/strict');
const jwt = require('jsonwebtoken');
const request = require('supertest');

process.env.DATABASE_PATH = ':memory:';
process.env.JWT_SECRET = 'test-secret-for-api-tests';

const { initializeDatabase } = require('../src/config/database');
const app = require('../src/app');

test('initialize in-memory SQLite database', async () => {
  await initializeDatabase();
});

test('registers a user and returns a JWT', async () => {
  const response = await request(app)
    .post('/api/auth/register')
    .send({ name: 'Student', email: 'student@example.com', password: 'valid-password' });

  assert.equal(response.status, 201);
  assert.equal(response.body.data.user.email, 'student@example.com');
  assert.equal(typeof response.body.data.token, 'string');
});

test('registration rejects a missing required name with 400', async () => {
  const response = await request(app)
    .post('/api/auth/register')
    .send({ email: 'missing-name@example.com', password: 'valid-password' });

  assert.equal(response.status, 400);
  assert.equal(response.body.success, false);
  assert.ok(response.body.errors.some((error) => error.field === 'name'));
});

test('category creation rejects a missing required name with 400', async () => {
  const login = await request(app)
    .post('/api/auth/login')
    .send({ email: 'student@example.com', password: 'valid-password' });

  const response = await request(app)
    .post('/api/categories')
    .set('Authorization', `Bearer ${login.body.data.token}`)
    .send({ description: 'No name included' });

  assert.equal(response.status, 400);
  assert.ok(response.body.errors.some((error) => error.field === 'name'));
});

test('unknown route returns a JSON 404 response', async () => {
  const response = await request(app).get('/api/not-a-real-route');

  assert.equal(response.status, 404);
  assert.equal(response.body.success, false);
  assert.match(response.body.message, /Route not found/);
});

test('malformed JSON request body returns 400', async () => {
  const response = await request(app)
    .post('/api/auth/register')
    .set('Content-Type', 'application/json')
    .send('{"broken":');

  assert.equal(response.status, 400);
  assert.equal(response.body.message, 'Request body contains invalid JSON.');
});

test('category and course CRUD work for an authenticated user', async () => {
  const login = await request(app)
    .post('/api/auth/login')
    .send({ email: 'student@example.com', password: 'valid-password' });
  const token = login.body.data.token;

  const createdCategory = await request(app)
    .post('/api/categories')
    .set('Authorization', `Bearer ${token}`)
    .send({ name: 'Programming', description: 'Programming courses' });
  assert.equal(createdCategory.status, 201);

  const categoryId = createdCategory.body.data.id;
  const listedCategories = await request(app)
    .get('/api/categories')
    .set('Authorization', `Bearer ${token}`);
  assert.equal(listedCategories.status, 200);
  assert.equal(listedCategories.body.data.length, 1);

  const createdCourse = await request(app)
    .post('/api/courses')
    .set('Authorization', `Bearer ${token}`)
    .send({
      title: 'Express Basics',
      description: 'Build APIs',
      price: 25,
      categoryId
    });
  assert.equal(createdCourse.status, 201);

  const courseId = createdCourse.body.data.id;
  assert.equal(createdCourse.body.data.categoryName, 'Programming');

  const updatedCourse = await request(app)
    .patch(`/api/courses/${courseId}`)
    .set('Authorization', `Bearer ${token}`)
    .send({ price: 30 });
  assert.equal(updatedCourse.status, 200);
  assert.equal(updatedCourse.body.data.price, 30);

  const blockedCategoryDelete = await request(app)
    .delete(`/api/categories/${categoryId}`)
    .set('Authorization', `Bearer ${token}`);
  assert.equal(blockedCategoryDelete.status, 409);

  const deletedCourse = await request(app)
    .delete(`/api/courses/${courseId}`)
    .set('Authorization', `Bearer ${token}`);
  assert.equal(deletedCourse.status, 200);

  const deletedCategory = await request(app)
    .delete(`/api/categories/${categoryId}`)
    .set('Authorization', `Bearer ${token}`);
  assert.equal(deletedCategory.status, 200);
});

test('invalid resource ID returns 400 validation response', async () => {
  const token = jwt.sign({}, process.env.JWT_SECRET, { subject: '1' });
  const response = await request(app)
    .get('/api/categories/not-a-number')
    .set('Authorization', `Bearer ${token}`);

  assert.equal(response.status, 400);
  assert.ok(response.body.errors.some((error) => error.field === 'id'));
});
