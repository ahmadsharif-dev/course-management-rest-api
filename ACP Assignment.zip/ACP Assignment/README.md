# Course Management REST API

A modular MVC REST API built with Express.js and SQLite. It includes user registration and login, plus authenticated category and course CRUD. Each signed-in user can access only their own categories and courses.

## Requirements

- Node.js 18 or newer
- Postman for the submission evidence

## Run locally

1. Install dependencies:

   ```powershell
   npm install
   ```
2. Copy `.env.example` to `.env`. Set `JWT_SECRET` to a long, random value. `DATABASE_PATH` defaults to `./data/course_api.sqlite`; the application creates the SQLite database and tables automatically. Do not submit or publish `.env`.
3. Start the server:

   ```powershell
   npm start
   ```

   The API listens at `http://localhost:3000`. Check `GET /health` for `{ "status": "ok" }`. The SQLite database is stored in the project's `data` folder by default.

For development with automatic restarts, use `npm run dev`.

## API endpoints

All request bodies use JSON. Except for registration and login, endpoints under `/api/categories` and `/api/courses` require the header `Authorization: Bearer <token>`. Use the token returned by registration or login.

### Authentication — `/api/auth`

| Method | Endpoint | Purpose | Success |
|---|---|---|---|
| POST | `/register` | Create an account with `name`, `email`, and `password` (minimum 8 characters) | 201 |
| POST | `/login` | Authenticate with `email` and `password` | 200 |

### Categories — `/api/categories`

| Method | Endpoint | Purpose | Success |
|---|---|---|---|
| POST | `/` | Create a category (`name`, optional `description`) | 201 |
| GET | `/` | List your categories | 200 |
| GET | `/:id` | Get one of your categories | 200 |
| PATCH | `/:id` | Update `name` and/or `description` | 200 |
| DELETE | `/:id` | Delete a category with no courses | 200 |

A category cannot be deleted while it contains your courses; the API responds with 409.

### Courses — `/api/courses`

| Method | Endpoint | Purpose | Success |
|---|---|---|---|
| POST | `/` | Create a course with `title`, `price`, and your `categoryId`; optional `description` and `level` | 201 |
| GET | `/` | List your courses | 200 |
| GET | `/:id` | Get one of your courses | 200 |
| PATCH | `/:id` | Update one or more course fields | 200 |
| DELETE | `/:id` | Delete a course | 200 |

`level` is `beginner`, `intermediate`, or `advanced` (defaults to `beginner`). Prices must be zero or greater.

### Error responses

Errors use a consistent JSON shape, for example:

```json
{
  "success": false,
  "message": "Validation failed.",
  "errors": [
    { "field": "name", "message": "Name is required." }
  ]
}
```

Missing/invalid request fields return 400, missing or invalid authentication returns 401, inaccessible or unknown routes/resources return 404, duplicate records return 409, and deleting a category that contains courses returns 409.

## Postman submission evidence

Import `postman/Course-Management-API.postman_collection.json` into Postman. Set the collection's `baseUrl` variable to `http://localhost:3000`. Run the requests in this order:

1. **Register** — saves the returned token to `accessToken`.
2. **Login** — also refreshes `accessToken`.
3. **Create category** — saves the new category ID as `categoryId`.
4. **List categories**.
5. **Missing required field (400)**.
6. **Unknown URL (404)**.
7. The remaining course CRUD examples.

The collection includes the bearer token automatically for protected requests. Capture these five screenshots in Postman:

1. Successful **Register** and **Login** responses (show both responses).
2. **Create category** with status **201 Created**.
3. **List categories** with status **200 OK**.
4. **Missing required field (400)** with status **400 Bad Request**.
5. **Unknown URL (404)** with status **404 Not Found**.

For every screenshot, write your name and roll number/ID at the top of the page, and keep the Postman request URL, HTTP method, headers, response status, and response body visible. Print the screenshots to PDF or submit the screenshots as directed by your instructor. The name/roll-number heading is intentionally a placeholder: add your own details before submitting. Do not edit or fabricate API response evidence.

## Run tests

```powershell
npm test
```

The tests use an in-memory SQLite database and exercise validation, authentication, and CRUD behavior.
